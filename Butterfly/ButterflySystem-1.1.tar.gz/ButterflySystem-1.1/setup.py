#!/usr/bin/env python
# _*_ coding:utf-8 _*_

from distutils.core import setup

setup(
    name="ButterflySystem",
    version="1.1",
    author="KylinChen",
    author_email="k1017856853@icoud.com",
    url="https://www.kylinchen.top",
    description="SJTU-CS214 python package",
    packages=['ButterflySystem', 'ButterflySystem.Data', 'ButterflySystem.Match'],
)
