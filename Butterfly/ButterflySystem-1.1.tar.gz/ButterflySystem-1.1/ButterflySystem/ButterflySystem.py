###################################################################################################################
# Butterfly System provide a reverse random-attractant model to online-update random distribution!
# `Class ButterflyNet provide a link-list relation in order to shorten running time
# `Class ButterflyNet provide a time-slice method to solver SFRouting
#     - init: read the data: order.csv  truck.csv  ship.csv  train.csv  plane.csv  as pandas.dataframe
#              (prototype: Butterfly(path, node_number, batch_number/core_number) )
#     - parse_matrix: slice the 24 hours into batch-slice and muti-process every time-slice to
#               generate init transport-matrix
#     - all_pair_shortest: find the time-slice (24 hours) corresponding all-pair shortest path
#               recursive by out-class staticmethod
#
#        Butterfly will achieve a random-method to find the approximation solution using Google's page algorithm
#        KylinChen, www.kylinchen.top, k1017856853@icloud.com
###################################################################################################################

# batch method
# from gurobipy import *

# data pre-process
import pandas as pd
import csv
import numpy as np
import sys

# visualization package
import matplotlib.pyplot as plt
# import plotly
# import plotly.graph_objs as go

# the sigmoid function-
# method: expit()
# import scipy.special

# achieve muti-process
import multiprocessing as mp
# import threading as td
import time


# Data class
class ButterflyNet:
    # init the variables of butterfly_net
    def __init__(self, NodeNumber, BatchNumber):
        self.nodeNumber = NodeNumber
        self.batchNumber = BatchNumber
        self.network = []
        for idx in range(BatchNumber):
            self.network.append([])
            for idy in range(NodeNumber+1):
                self.network[idx].append([])

    def networkOut(self):
        print(len(self.network))
        print(len(self.network[0]))
        # print(len(self.network[23]))

    def addTag(self, tag):
        self.network.append(tag)

    def addItem(self, source, sink, offset, cost):
        self.network[0][source].append((sink, offset, cost))

    def Index(self, location):
        return self.network[location]


# Method class
class ButterflySystem:
    # init the variables of butterfly_system
    def __init__(self, CSVFilePath, NodeNumber, BatchNumber=24):
        self.filePath = CSVFilePath
        self.nodeNumber = NodeNumber
        self.batchNumber = BatchNumber
        self.hushkeys = self.keys_generator(NodeNumber**1.4)
        self.orders_df = self.read_orders()
        self.trans_df_list = self.read_trans()
        self.slice_dict = {}

    # Multi-Process get the data-matrix(self-attribute time-slice)
    def parse_matrix(self):
        manager = mp.Manager()
        queue = manager.Queue()
        processpool = []
        time_slice = 24*60//self.batchNumber
        for idx in range(self.batchNumber):
            start = idx*time_slice
            end = (1+idx)*time_slice
            processpool.append(mp.Process(target=self._parse_matrix_subprocess, args=(idx, start, end, queue, )))
            processpool[idx].start()
        for idx in range(self.batchNumber):
            processpool[idx].join()
        for idx in range(self.batchNumber):
            mat = queue.get()
            self.slice_dict[mat.Index(1)] = mat.Index(0)
            pass
        pass

    def _parse_matrix_subprocess(self, tag, start, end, queue):
        res = ButterflyNet(self.nodeNumber, 1)
        res.addTag(tag)
        for transport in range(4):
            # [0]:truck, [1]:train, [2]:ship, [3]:plane
            dataframe = self.trans_df_list[transport]
            aim_df = dataframe.loc[(dataframe["Departure time"] >= start) & (dataframe["Departure time"] < end)]
            for idx, column in aim_df.iterrows():
                source = int(column["Departure city index"])
                sink = int(column["Arrival city index"])
                offset = int(column["Arrival time"]//(end - start))
                offset = offset % 24
                cost = column["Cost for every 1kg good"]
                res.addItem(source, sink, offset, cost)
                print(tag, idx)
        queue.put(res)
        # sys.exit()

    # Data Operation-Method part
    def data_out(self):
        return self.slice_dict

    def read_orders(self, rewrite=0):
        csv = pd.read_csv(self.filePath + "/orders.csv")
        dataframe = pd.DataFrame(csv)
        dataframe = dataframe.sort_values(by=["City of Seller", "City of Purchaser", "Time of Order"])
        # change by items in list of dataframe.columns
        if (rewrite):
            dataframe.to_csv(self.filePath + "/orders.csv", encoding='utf-8')
            pass
        # dataframe.to_csv("../sourceData/orders.csv")
        return dataframe
        pass

    def read_trans(self, rewrite=0):
        transport = ["/truck.csv", "/train.csv", "/ship.csv", "/plane.csv"]
        DFlist = []
        for file in transport:
            csv = pd.read_csv(self.filePath + file)
            dataframe = pd.DataFrame(csv)
            dataframe = dataframe.sort_values(by=["Departure time",  "Arrival time"])
            if (rewrite):
                dataframe.to_csv(self.filePath + file, encoding='utf-8')
                pass
            DFlist.append(dataframe)
        return DFlist
        pass

    # Hush-Key Generator System
    # @staticmethod
    def keys_generator(self, num):
        keylist=[]
        for idx in self.prime_generator():
            if idx < num:
                keylist.append(idx)
                pass
            else:
                break
        return keylist
        pass

    # @staticmethod
    def odd_generator(self):
        idx = 1
        while True:
            idx += 2
            yield idx

    def not_divisible(self, n):
        return lambda x: x % n > 0

    def prime_generator(self):
        idx = 2
        it = self.odd_generator()
        while True:
            idx = next(it)
            yield idx
            it = filter(self.not_divisible(idx), it)

    def KeyOut(self):
        print(self.hushkeys)

    # get Approximation-solution, provide training chance to update latter
    def random_all_pair_shortest(self):
        all_shortest = np.zeros((self.batchNumber, self.nodeNumber+1, self.nodeNumber+1), dtype=np.float)
        for source in range(1, self.nodeNumber+1, 1):
            for sink in range(1, self.nodeNumber+1, 1):
                if(source == sink):
                    pass
                for batch_number in range(self.batchNumber):
                    all_shortest[batch_number][source][sink] = _cur_single_pair(self.slice_dict, batch_number, source,
                                                                                sink, 0, 0)
                    print(batch_number, ":", source, "->", sink, "=", all_shortest[batch_number][source][sink])
                    pass

    # get OPT-solution by adding global variable
    def opt_all_pair_shortest(self):
        all_shortest = np.zeros((self.batchNumber, self.nodeNumber + 1, self.nodeNumber + 1), dtype=np.float)
        for source in range(1, self.nodeNumber + 1, 1):
            for sink in range(1, self.nodeNumber + 1, 1):
                if (source == sink):
                    pass
                for batch_number in range(self.batchNumber):
                    local_top = 1000
                    _global_cur_single_pair(self.slice_dict, batch_number, source, sink, 0, 0)
                    all_shortest[batch_number][source][sink] = local_top
                    print(batch_number, ":", source, "->", sink, "=", all_shortest[batch_number][source][sink])
                    pass
        pass


# recursive single-pair shortest
def _cur_single_pair(dict, batch_number, source, sink, local_min, depth):
    # print("!", batch_number, "!")
    if(depth > 7):
        return -2
    local_list = dict[batch_number][source]
    for local_aim in local_list:
        if(local_aim[0] == sink):
            return local_min+local_aim[2]
    for local_aim in local_list:
        return _cur_single_pair(dict, local_aim[1], local_aim[0], sink, local_min+local_aim[2], depth+1)
    return -1


def _global_cur_single_pair(dict, batch_number, source, sink, local_min, depth):
    # print("!", batch_number, "!")
    if (depth > 3):
        return 0
    local_list = dict[batch_number][source]
    for local_aim in local_list:
        if ((local_aim[0] == sink) and (local_min + local_aim[2] < local_top)):
            local_top = local_min + local_aim[2]
    for local_aim in local_list:
        _cur_single_pair(dict, local_aim[1], local_aim[0], sink, local_min + local_aim[2], depth + 1)
    return -1
    pass


if __name__ == '__main__':
    # m=ButterflySystem("../sourceData/change", 665, 24)
    # m.KeyOut()
    # k=ButterflyNet(645, 1)
    # k.networkOut()
    st1 = time.time()
    m = ButterflySystem("../sourceData/change", 656, 24)
    m.parse_matrix()
    m.random_all_pair_shortest()
    st2 = time.time()
    print("time: ", st2-st1)
    print(m.slice_dict[23])
